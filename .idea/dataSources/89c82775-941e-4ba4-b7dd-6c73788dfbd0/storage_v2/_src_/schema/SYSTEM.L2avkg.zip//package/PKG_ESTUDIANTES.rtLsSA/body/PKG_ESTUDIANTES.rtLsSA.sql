create package body pkg_estudiantes as



FUNCTION fnc_calcular_promedio
 (
 codigo_estudiante  Estudiante.codigoEstudiante%type
 )
RETURN Nota.nota%type
AS v_promedio Nota.nota%type; 

BEGIN
    
    SELECT AVG(nota)
    INTO v_promedio
    FROM Nota
    WHERE CodigoEstudiante = codigo_estudiante;
    
    return v_promedio;
    
END;

end pkg_estudiantes;
/

