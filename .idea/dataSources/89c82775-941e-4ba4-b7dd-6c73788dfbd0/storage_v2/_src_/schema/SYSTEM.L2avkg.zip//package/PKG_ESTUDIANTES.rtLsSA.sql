create package pkg_estudiantes as 

function fnc_calcular_promedio ( codigo_estudiante  Estudiante.codigoEstudiante%type) return Nota.nota%type;

end pkg_estudiantes;
/

