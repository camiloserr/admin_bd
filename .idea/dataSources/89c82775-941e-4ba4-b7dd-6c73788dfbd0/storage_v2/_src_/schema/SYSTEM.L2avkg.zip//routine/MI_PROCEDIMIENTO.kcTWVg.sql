create PROCEDURE mi_procedimiento (c_codigo CIUDAD.CODIGOCIUDAD%TYPE) IS
c_nombre CIUDAD.NOMBRECIUDAD%type;
BEGIN
	select nombreciudad
	into c_nombre
	FROM Ciudad
	where codigociudad = c_codigo;
End mi_procedimiento;
/

