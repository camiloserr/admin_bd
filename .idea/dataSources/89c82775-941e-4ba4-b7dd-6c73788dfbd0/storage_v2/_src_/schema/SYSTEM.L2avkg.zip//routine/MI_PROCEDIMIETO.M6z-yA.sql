create PROCEDURE mi_procedimieto IS
BEGIN
	select *
	FROM Ciudad;
End mi_procedimiento;
/

