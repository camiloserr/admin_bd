create PROCEDURE procedimiento_insertar IS
DECLARE counter NUMBER := 0;
BEGIN
  LOOP
    counter := counter + 1;
    DBMS_OUTPUT.PUT_LINE(counter);
    EXIT WHEN counter = 10;
  END LOOP;
END procedimiento_insertar;
/

