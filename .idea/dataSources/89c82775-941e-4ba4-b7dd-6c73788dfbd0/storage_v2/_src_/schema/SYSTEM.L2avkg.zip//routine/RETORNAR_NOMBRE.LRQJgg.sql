create function retornar_nombre(p_codigo Estudiantes.codigo%TYPE) RETURN varchar2 is

    v_nombre Estudiantes.nombre%TYPE;
    begin
    select nombre
    into v_nombre
    from Estudiantes
    where codigo = p_codigo;
    return v_nombre;

end retornar_nombre;
/

