create view VIEW_PROFESORES as
(SELECT IDProfesor,Nombres,Apellidos,IDDirector FROM Profesor)
/

