create procedure contarProfesores is
begin
    dbms_output.put_line('Realizar procedure contarProfesores');
end contarProfesores;
/

