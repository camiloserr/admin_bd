create function contarDirectores
    return number
    is
begin
    dbms_output.put_line('Realizar function contarDirectores');
    return(1);
end contarDirectores;
/

